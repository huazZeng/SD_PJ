package org.example.command;

public interface CanUndoCommand extends Command {
    void undo();
}
