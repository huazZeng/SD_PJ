package org.example.command;

public interface IOCommand extends Command {
}
