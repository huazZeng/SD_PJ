package org.example.console;

public class CommandHandler {
}
